import 'package:flutter/material.dart';

/// Tokens de la Phase 0. Le vert = etats positifs, le rouge = erreurs et
/// stock critique, le dore = accent discret uniquement.
class TjColors {
  static const navy = Color(0xFF14263D);
  static const background = Color(0xFFF7F8FA);
  static const surface = Color(0xFFFFFFFF);
  static const success = Color(0xFF16856B);
  static const accent = Color(0xFFE5A93D);
  static const text = Color(0xFF1B2430);
  static const textSecondary = Color(0xFF687386);
  static const border = Color(0xFFE3E7ED);
  static const danger = Color(0xFFC83D4D);
  static const warning = Color(0xFFD99122);

  // Mode sombre: valeurs de depart, contraste AA a verifier a l'ecran.
  static const darkBackground = Color(0xFF0F1722);
  static const darkSurface = Color(0xFF17222F);
  static const darkText = Color(0xFFE8ECF2);
  static const darkTextSecondary = Color(0xFF9AA6B8);
  static const darkBorder = Color(0xFF283546);
  static const darkPrimary = Color(0xFF9DB8D9);
}

class TjSpacing {
  static const double xs = 4, s = 8, m = 12, l = 16, xl = 24, xxl = 32;
}

class TjRadius {
  static const double field = 8, card = 12;
}
