import 'package:flutter/material.dart';
import 'tokens.dart';

ThemeData buildLightTheme() => _base(
      ColorScheme.light(
        primary: TjColors.navy,
        onPrimary: Colors.white,
        secondary: TjColors.success,
        tertiary: TjColors.accent,
        error: TjColors.danger,
        surface: TjColors.surface,
        onSurface: TjColors.text,
        outline: TjColors.border,
      ),
      scaffold: TjColors.background,
      secondaryText: TjColors.textSecondary,
    );

ThemeData buildDarkTheme() => _base(
      ColorScheme.dark(
        primary: TjColors.darkPrimary,
        onPrimary: TjColors.darkBackground,
        secondary: TjColors.success,
        tertiary: TjColors.accent,
        error: TjColors.danger,
        surface: TjColors.darkSurface,
        onSurface: TjColors.darkText,
        outline: TjColors.darkBorder,
      ),
      scaffold: TjColors.darkBackground,
      secondaryText: TjColors.darkTextSecondary,
    );

ThemeData _base(ColorScheme scheme,
    {required Color scaffold, required Color secondaryText}) {
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: scaffold,
    // Chiffres alignes pour les montants.
    textTheme: ThemeData(brightness: scheme.brightness).textTheme.apply(
          bodyColor: scheme.onSurface,
          displayColor: scheme.onSurface,
        ),
    cardTheme: CardThemeData(
      color: scheme.surface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(TjRadius.card),
        side: BorderSide(color: scheme.outline),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(TjRadius.field),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: scheme.surface,
      indicatorColor: scheme.primary.withValues(alpha: 0.12),
    ),
  );
}
