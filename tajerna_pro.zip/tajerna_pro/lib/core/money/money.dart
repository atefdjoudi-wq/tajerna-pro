import 'rounding.dart';

/// Quantite: 1 unite = 1000 milli-unites (permet 2,5 kg = 2500).
const int kMilli = 1000;

/// Montant en centimes (1 DZD = 100 centimes). Jamais de double.
extension MoneyMath on int {
  /// prix unitaire (centimes) x quantite (milli-unites) -> centimes.
  int timesQtyMilli(int qtyMilli) => roundDiv(this * qtyMilli, kMilli);
}

/// Formate des centimes en texte, ex: 12050 -> "120,50".
/// (Le separateur et les chiffres arabes seront geres par l10n en Phase 1.)
String formatCentimes(int centimes, {String decimalSeparator = ','}) {
  final negative = centimes < 0;
  final abs = centimes.abs();
  final whole = abs ~/ 100;
  final frac = (abs % 100).toString().padLeft(2, '0');
  return '${negative ? '-' : ''}$whole$decimalSeparator$frac';
}
