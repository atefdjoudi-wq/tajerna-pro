/// Division entiere avec arrondi "half away from zero".
/// Utilisee partout ou un montant ou une quantite est divise, pour avoir
/// une seule regle d'arrondi dans toute l'application.
int roundDiv(int numerator, int denominator) {
  if (denominator <= 0) {
    throw ArgumentError.value(denominator, 'denominator', 'must be > 0');
  }
  final q = numerator ~/ denominator; // tronque vers zero
  final r = numerator.remainder(denominator); // meme signe que numerator
  if (r.abs() * 2 >= denominator) {
    return numerator >= 0 ? q + 1 : q - 1;
  }
  return q;
}
