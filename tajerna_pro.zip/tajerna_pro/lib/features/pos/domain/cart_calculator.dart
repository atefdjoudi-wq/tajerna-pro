import '../../../core/money/money.dart';
import '../../../core/money/rounding.dart';

class CartLine {
  const CartLine({
    required this.productId,
    required this.unitPrice,
    required this.qtyMilli,
    this.discount = 0,
  });
  final String productId;
  final int unitPrice; // centimes
  final int qtyMilli;
  final int discount; // centimes, remise de ligne

  int get gross => unitPrice.timesQtyMilli(qtyMilli);
  int get total => gross - discount;
}

class CartTotals {
  const CartTotals({
    required this.subtotal,
    required this.orderDiscount,
    required this.net,
    required this.tax,
    required this.total,
  });
  final int subtotal; // somme des lignes apres remises de ligne
  final int orderDiscount;
  final int net; // subtotal - orderDiscount
  final int tax;
  final int total; // net + tax
}

enum PaymentStatus { paid, partial, credit }

class PaymentOutcome {
  const PaymentOutcome({
    required this.status,
    required this.paid,
    required this.due,
    required this.change,
  });
  final PaymentStatus status;
  final int paid; // montant effectivement impute a la vente
  final int due; // reste a credit (dette client)
  final int change; // monnaie rendue
}

class InvalidCartException implements Exception {
  InvalidCartException(this.message);
  final String message;
  @override
  String toString() => 'InvalidCartException: $message';
}

class CustomerRequiredForCreditException implements Exception {
  @override
  String toString() => 'CustomerRequiredForCreditException';
}

/// Calcul pur des totaux. `taxBp` en points de base (1900 = 19 %),
/// applique en une seule fois sur le net (taxe exclue des prix), arrondi unique.
CartTotals computeTotals(
  List<CartLine> lines, {
  int orderDiscount = 0,
  int taxBp = 0,
}) {
  for (final l in lines) {
    if (l.qtyMilli <= 0) throw InvalidCartException('quantity must be > 0');
    if (l.unitPrice < 0) throw InvalidCartException('price must be >= 0');
    if (l.discount < 0 || l.discount > l.gross) {
      throw InvalidCartException('line discount out of range');
    }
  }
  final subtotal = lines.fold<int>(0, (s, l) => s + l.total);
  if (orderDiscount < 0 || orderDiscount > subtotal) {
    throw InvalidCartException('order discount out of range');
  }
  final net = subtotal - orderDiscount;
  final tax = roundDiv(net * taxBp, 10000);
  return CartTotals(
    subtotal: subtotal,
    orderDiscount: orderDiscount,
    net: net,
    tax: tax,
    total: net + tax,
  );
}

/// Determine le statut de paiement. Une vente a credit n'est PAS un
/// encaissement: `paid` ne compte que l'argent reellement recu.
PaymentOutcome settle({
  required int total,
  required int tendered,
  required bool hasCustomer,
}) {
  if (tendered < 0) throw InvalidCartException('tendered must be >= 0');
  if (tendered >= total) {
    return PaymentOutcome(
      status: PaymentStatus.paid,
      paid: total,
      due: 0,
      change: tendered - total,
    );
  }
  if (!hasCustomer) throw CustomerRequiredForCreditException();
  return PaymentOutcome(
    status: tendered == 0 ? PaymentStatus.credit : PaymentStatus.partial,
    paid: tendered,
    due: total - tendered,
    change: 0,
  );
}
