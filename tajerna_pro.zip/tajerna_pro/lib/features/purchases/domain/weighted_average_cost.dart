import '../../../core/money/money.dart';
import '../../../core/money/rounding.dart';

/// Cout moyen pondere apres un achat. Tout en entiers.
///
/// cout moyen = (valeur stock avant + valeur achat) / quantite totale apres
///
/// Regles:
/// - stock avant <= 0 (ex: survente): la valeur avant est ignoree, le
///   nouveau cout est celui de l'achat (frais inclus).
/// - Les couts historiques ne sont jamais recalcules: chaque vente fige
///   son `cost_at_sale`.
/// Retourne le nouveau cout moyen par unite, en centimes.
int weightedAverageCost({
  required int stockQtyMilliBefore,
  required int avgCostBefore,
  required int purchaseQtyMilli,
  required int purchaseUnitCost,
  int extraCosts = 0,
}) {
  if (purchaseQtyMilli <= 0) {
    throw ArgumentError.value(purchaseQtyMilli, 'purchaseQtyMilli', 'must be > 0');
  }
  final valueBefore = stockQtyMilliBefore > 0
      ? avgCostBefore.timesQtyMilli(stockQtyMilliBefore)
      : 0;
  final qtyBefore = stockQtyMilliBefore > 0 ? stockQtyMilliBefore : 0;
  final purchaseValue = purchaseUnitCost.timesQtyMilli(purchaseQtyMilli) + extraCosts;
  final totalValue = valueBefore + purchaseValue;
  final totalQty = qtyBefore + purchaseQtyMilli;
  return roundDiv(totalValue * kMilli, totalQty);
}
