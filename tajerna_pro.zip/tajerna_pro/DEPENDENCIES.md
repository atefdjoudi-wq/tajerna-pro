# Dependances

## Presentes dans pubspec.yaml
flutter (sdk), flutter_localizations (sdk), intl (version imposee par le SDK), flutter_test (dev).

## Prevues, NON encore ajoutees (a verifier avec `flutter pub add`, puis noter la version resolue ici)
| Besoin | Paquet candidat | Verification requise |
|---|---|---|
| Etat | flutter_riverpod | - |
| Navigation | go_router | - |
| DB | drift, drift_dev, build_runner | - |
| Chiffrement DB | sqlcipher_flutter_libs | compatibilite reelle avec la version de Drift sur appareil |
| Secrets | flutter_secure_storage | minSdk |
| Scan | mobile_scanner ou google_mlkit_barcode_scanning | minSdk, permissions camera |
| PDF/impression | pdf, printing | polices arabes dans le PDF |
| ESC/POS Bluetooth | a choisir | maintenance et compatibilite |
| Excel/CSV | excel, csv | - |
| Graphiques | fl_chart | RTL |
| Ed25519 | cryptography ou pinenacl | - |
| Tests | mocktail | - |
