# Tajerna Pro (Phase 1 - fondations, en cours)

Etat: **non compile, non teste dans Flutter** (aucun SDK dans l'environnement de generation). Voir STATUS.md.

## Prerequis
- Flutter stable recent (le code utilise `CardThemeData` et `Color.withValues`, donc une version recente) et Android Studio avec le SDK Android.
- Verifier: `flutter --version` puis `flutter doctor`.

## Mise en route (dans le dossier du projet)
```
flutter create --org dz.tajerna --project-name tajerna_pro .
flutter pub get
flutter analyze
flutter test
flutter run
```
`flutter create .` ajoute les dossiers `android/` (Gradle wrapper, AndroidManifest.xml) sans ecraser `lib/` ni `pubspec.yaml`; si un fichier est ecrase, restaurer depuis Git.

## Android Studio
File > Open sur le dossier, attendre le Gradle Sync, choisir un emulateur ou un telephone, Run.

## Builds
```
flutter build apk --release
flutter build appbundle --release
```
La signature de release (keystore) reste locale: `android/key.properties` et `*.jks` sont ignores par Git.

## Dependances a ajouter ensuite
Voir DEPENDENCIES.md. Les versions sont resolues par `flutter pub add`, pas ecrites de memoire.

## Depannage
- `flutter doctor` signale le SDK Android manquant: l'installer via Android Studio > SDK Manager.
- Erreur sur `CardThemeData`/`withValues`: mettre a jour Flutter (`flutter upgrade`).

## Obtenir un APK sans installer Flutter (GitHub Actions)
1. Creer un depot GitHub (prive) et y envoyer tout le contenu de ce dossier, y compris `.github/`.
2. Onglet Actions > "Build APK" > Run workflow (ou simple push sur `main`).
3. A la fin, ouvrir l'execution et telecharger l'artefact `tajerna-pro-apk` (contient `app-release.apk`).
4. Copier l'APK sur le telephone Android et l'installer (autoriser les sources inconnues).

Notes: le workflow genere `android/` lui-meme; l'APK est signe avec la cle de debug de Flutter, donc valable pour tester, pas pour Google Play. Si le build echoue, le journal de l'etape en erreur indique la cause.
