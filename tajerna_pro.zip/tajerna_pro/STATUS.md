# Statut (Phase 1, debut)

## Ecrit
- pubspec minimal, .gitignore, .env.example, analysis_options
- core/money: roundDiv (half away from zero), centimes entiers, quantites en milli-unites
- purchases/domain: cout moyen pondere (stock negatif et frais geres)
- pos/domain: totaux (remises, taxe en points de base), statut de paiement (comptant, partiel, credit sans client refuse)
- design_system: tokens et themes clair/sombre
- coque de navigation 5 onglets (placeholders, aucune donnee)
- fichiers .arb ar/fr/en (non branches)
- tests unitaires pour tout ce qui precede

## Verifie
- Les valeurs attendues des tests ont ete recalculees par un miroir Python independant (OK).

## NON verifie
- Aucune compilation, aucun `flutter analyze`, aucun `flutter test` (pas de SDK Flutter ici).
- Dossier android/ absent: genere par `flutter create .`.

## Pas commence
Drift/SQLCipher, produits, stock, POS ecran, factures, Dashboard reel, l10n branche, polices, Riverpod; Phases 2 a 7.
