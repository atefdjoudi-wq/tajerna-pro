import 'package:flutter_test/flutter_test.dart';
import 'package:tajerna_pro/core/money/money.dart';
import 'package:tajerna_pro/core/money/rounding.dart';

void main() {
  group('roundDiv (half away from zero)', () {
    test('positifs', () {
      expect(roundDiv(5, 2), 3);
      expect(roundDiv(4, 3), 1);
      expect(roundDiv(1, 3), 0);
    });
    test('negatifs', () {
      expect(roundDiv(-5, 2), -3);
      expect(roundDiv(-1, 3), 0);
    });
    test('denominateur invalide', () {
      expect(() => roundDiv(1, 0), throwsArgumentError);
    });
  });

  group('timesQtyMilli', () {
    test('quantite decimale exacte (2,5 kg a 120,50)', () {
      expect(12050.timesQtyMilli(2500), 30125);
    });
    test('arrondi a la demi-unite', () {
      expect(333.timesQtyMilli(1500), 500); // 499,5 -> 500
    });
  });

  test('formatCentimes', () {
    expect(formatCentimes(12050), '120,50');
    expect(formatCentimes(5), '0,05');
    expect(formatCentimes(-250), '-2,50');
  });
}
