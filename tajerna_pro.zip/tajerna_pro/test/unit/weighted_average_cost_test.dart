import 'package:flutter_test/flutter_test.dart';
import 'package:tajerna_pro/features/purchases/domain/weighted_average_cost.dart';

void main() {
  test('deux lots a prix differents', () {
    // 10 unites a 100,00 + 10 unites a 120,00 -> 110,00
    expect(
      weightedAverageCost(
        stockQtyMilliBefore: 10000,
        avgCostBefore: 10000,
        purchaseQtyMilli: 10000,
        purchaseUnitCost: 12000,
      ),
      11000,
    );
  });

  test('stock vide + frais d\'achat repartis sur la quantite', () {
    // 10 unites a 120,00 + 50,00 de frais -> 125,00
    expect(
      weightedAverageCost(
        stockQtyMilliBefore: 0,
        avgCostBefore: 0,
        purchaseQtyMilli: 10000,
        purchaseUnitCost: 12000,
        extraCosts: 5000,
      ),
      12500,
    );
  });

  test('arrondi unique en centimes', () {
    // (3 x 10,00 + 1 x 10,01) / 4 = 10,0025 -> 10,00
    expect(
      weightedAverageCost(
        stockQtyMilliBefore: 3000,
        avgCostBefore: 1000,
        purchaseQtyMilli: 1000,
        purchaseUnitCost: 1001,
      ),
      1000,
    );
  });

  test('stock negatif avant achat: le nouveau cout est celui de l\'achat', () {
    expect(
      weightedAverageCost(
        stockQtyMilliBefore: -2000,
        avgCostBefore: 500,
        purchaseQtyMilli: 5000,
        purchaseUnitCost: 800,
      ),
      800,
    );
  });

  test('quantite d\'achat invalide', () {
    expect(
      () => weightedAverageCost(
        stockQtyMilliBefore: 0,
        avgCostBefore: 0,
        purchaseQtyMilli: 0,
        purchaseUnitCost: 100,
      ),
      throwsArgumentError,
    );
  });
}
