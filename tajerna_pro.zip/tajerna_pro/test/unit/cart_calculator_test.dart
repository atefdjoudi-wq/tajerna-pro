import 'package:flutter_test/flutter_test.dart';
import 'package:tajerna_pro/features/pos/domain/cart_calculator.dart';

void main() {
  final lines = [
    const CartLine(productId: 'A', unitPrice: 10000, qtyMilli: 2000), // 200,00
    const CartLine(
        productId: 'B', unitPrice: 2500, qtyMilli: 1000, discount: 500), // 20,00
  ];

  group('computeTotals', () {
    test('remises + taxe en points de base', () {
      final t = computeTotals(lines, orderDiscount: 2000, taxBp: 1900);
      expect(t.subtotal, 22000);
      expect(t.net, 20000);
      expect(t.tax, 3800);
      expect(t.total, 23800);
    });
    test('sans taxe ni remise', () {
      expect(computeTotals(lines).total, 22000);
    });
    test('remise de ligne superieure au brut refusee', () {
      expect(
        () => computeTotals([
          const CartLine(
              productId: 'X', unitPrice: 100, qtyMilli: 1000, discount: 101)
        ]),
        throwsA(isA<InvalidCartException>()),
      );
    });
    test('quantite nulle refusee', () {
      expect(
        () => computeTotals([
          const CartLine(productId: 'X', unitPrice: 100, qtyMilli: 0)
        ]),
        throwsA(isA<InvalidCartException>()),
      );
    });
  });

  group('settle', () {
    test('espece exacte', () {
      final p = settle(total: 23800, tendered: 23800, hasCustomer: false);
      expect(p.status, PaymentStatus.paid);
      expect(p.change, 0);
    });
    test('monnaie rendue', () {
      final p = settle(total: 23800, tendered: 25000, hasCustomer: false);
      expect(p.paid, 23800);
      expect(p.change, 1200);
    });
    test('paiement partiel avec client', () {
      final p = settle(total: 23800, tendered: 10000, hasCustomer: true);
      expect(p.status, PaymentStatus.partial);
      expect(p.due, 13800);
    });
    test('vente a credit: rien d\'encaisse', () {
      final p = settle(total: 23800, tendered: 0, hasCustomer: true);
      expect(p.status, PaymentStatus.credit);
      expect(p.paid, 0);
      expect(p.due, 23800);
    });
    test('credit sans client refuse', () {
      expect(
        () => settle(total: 100, tendered: 0, hasCustomer: false),
        throwsA(isA<CustomerRequiredForCreditException>()),
      );
    });
  });
}
